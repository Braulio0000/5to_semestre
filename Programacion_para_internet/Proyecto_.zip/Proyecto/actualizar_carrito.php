<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['idUser'])) {
    die("Debe estar logueado para actualizar el carrito.");
}

// Obtener los datos del producto y la cantidad
$idProducto = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$cantidad = isset($_POST['cantidad']) ? (int)$_POST['cantidad'] : 0;

// Validar existencia del carrito y actualizar la cantidad
if (isset($_SESSION['carrito'][$idProducto]) && $cantidad > 0) {
    $_SESSION['carrito'][$idProducto]['cantidad'] = $cantidad;
    echo json_encode(['status' => 'success', 'message' => 'Cantidad actualizada.']);
} elseif ($cantidad === 0) {
    // Eliminar el producto si la cantidad es 0
    unset($_SESSION['carrito'][$idProducto]);
    echo json_encode(['status' => 'success', 'message' => 'Producto eliminado del carrito.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Producto no encontrado.']);
}
?>
