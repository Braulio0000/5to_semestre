<?php
$to = "pramirezquino@gmail.com"; // Cambia por un correo real
$subject = "Correo de prueba";
$body = "Este es un correo de prueba enviado desde PHP.";
$headers = "From: christiancom2244@gmail.com\r\n";

if (mail($to, $subject, $body, $headers)) {
    echo "Correo enviado exitosamente.";
} else {
    echo "Error al enviar el correo.";
}
?>
