<?php
session_start();
if (!isset($_SESSION['idUser'])) {
    header("Location: loginCliente.php");
    exit();
}

// Manejar el evento de agregar al carrito
if (isset($_POST['id_producto']) && isset($_POST['cantidad'])) {
    $idProducto = $_POST['id_producto'];
    $cantidad = (int)$_POST['cantidad'];

    // Inicializar el carrito si no está definido
    if (!isset($_SESSION['carrito'])) {
        $_SESSION['carrito'] = [];
    }

    // Agregar o actualizar el producto en el carrito
    if (isset($_SESSION['carrito'][$idProducto]) && is_array($_SESSION['carrito'][$idProducto])) {
        $_SESSION['carrito'][$idProducto]['cantidad'] += $cantidad;
    } else {
        $_SESSION['carrito'][$idProducto] = [
            'producto_id' => $idProducto,
            'cantidad' => $cantidad
        ];
    }
    echo json_encode(['status' => 'success']);  // Confirmar que se ha agregado
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Productos</title>
    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="producto.css">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <!-- Incluye Bootstrap y FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
    $(document).ready(function() {
        // Asegurarnos de que el valor del input hidden se actualice cuando se cambia la cantidad
        $('input[type="number"]').on('input', function() {
            var cantidadInput = $(this).val();
            var hiddenInput = $(this).siblings('input[type="hidden"][name="cantidad"]');
            hiddenInput.val(cantidadInput);
        });

        $(".agregar .btn").on("click", function(event) {
            event.preventDefault();
            
            var idProducto = $(this).siblings('input[name="id_producto"]').val();
            var cantidad = $(this).siblings('input[name="cantidad"]').val();

            $.ajax({
                url: 'producto.php',
                method: 'POST',
                data: { id_producto: idProducto, cantidad: cantidad },
                success: function(response) {
                    var result = JSON.parse(response);
                    if (result.status === 'success') {
                        // Producto agregado al carrito, actualizar la interfaz sin recargar
                        // Aquí puedes añadir lógica para actualizar el carrito visible en la página, si es necesario
                    } else {
                        // Manejar otros posibles estados
                    }
                }
            });
        });
    });
    </script>
</head>
<body>
<div class="container">
    <!-- Menú de navegación -->
    <div class="menu d-flex justify-content-between align-items-center">
        <div>
            <a href="index.php">HOME</a>
            <a href="producto.php">PRODUCTOS</a>
            <a href="contacto.php">CONTACTO</a>
            <?php
            // Verificar si la sesión está activa
            if (isset($_SESSION['nombreUser'])) {
                echo '<a href="loginOut.php">CERRAR SESIÓN</a>';
                echo '<p class="welcome-message">Bienvenido, ' . $_SESSION['nombreUser'] . '</p>';
            } else {
                echo '<a href="loginCliente.php">LOG IN</a>';
            }
            ?>
        </div>
        <!-- Redes sociales y carrito -->
        <div class="d-flex align-items-center">
            <!-- Íconos de redes sociales -->
            <a href="https://www.facebook.com" target="_blank" class="ml-3" title="Facebook">
                <i class="fab fa-facebook-f" style="font-size: 24px; color: #4267B2;"></i>
            </a>
            <a href="https://www.twitter.com" target="_blank" class="ml-3" title="Twitter">
                <i class="fab fa-twitter" style="font-size: 24px; color: #1DA1F2;"></i>
            </a>
            <a href="https://www.instagram.com" target="_blank" class="ml-3" title="Instagram">
                <i class="fab fa-instagram" style="font-size: 24px; color: #E4405F;"></i>
            </a>
            <!-- Ícono del carrito -->
            <a href="carrito.php" class="cart-icon ml-3" title="Carrito">
                <i class="fas fa-shopping-cart" style="font-size: 24px;"></i>
            </a>
        </div>
    </div>
    
    <!-- Título -->
    <h2 class="text-center mt-4">Productos disponibles</h2>
    <div class="d-flex justify-content-end mb-4"> 
        <a href="index.php" class="btn btn-secondary">REGRESAR</a> 
    </div>

    <div class="row">
        <?php
        include 'funciones/conecta_productos.php'; // Conexión a la base de datos
        $con = conecta();
        $query = "SELECT * FROM productos WHERE eliminado = 0";
        $resultado = $con->query($query);

        if ($resultado->num_rows > 0) {
            while ($producto = $resultado->fetch_assoc()) {
                echo '<div class="col-md-4 mb-4">';
                echo '<div class="card producto">';
                echo '<img src="administrador/archivos_productos/' . $producto['archivo'] . '" class="card-img-top" alt="' . $producto['nombre'] . '">';
                echo '<div class="card-body">';
                echo '<h5 class="card-title">' . $producto['nombre'] . '</h5>';
                echo '<p class="card-text">$' . $producto['costo'] . '</p>';
                echo '<p class="card-text">Código: ' . $producto['codigo'] . '</p>';

                // Mostrar botón de "Agregar al carrito" y cantidad solo si está logueado
                if (isset($_SESSION['nombreUser'])) {
                    echo '<div class="agregar">';
                    echo '<form method="POST" action="producto.php" class="mb-0">';
                    echo '<input type="hidden" name="id_producto" value="' . $producto['id'] . '">';
                    echo '<input type="number" name="cantidad" class="form-control mr-2" id="cantidad-' . $producto['id'] . '" placeholder="Cantidad" min="1" value="1">';
                    echo '<button type="submit" class="btn btn-primary">Agregar al carrito</button>';
                    echo '</form>';
                    echo '</div>';
                }

                echo '<a href="producto_detalle.php?id=' . $producto['id'] . '" class="btn btn-info mt-2">Ver detalles</a>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo '<p>No hay productos disponibles.</p>';
        }

        $con->close();
        ?>
    </div>
</div>
</body>
</html>
