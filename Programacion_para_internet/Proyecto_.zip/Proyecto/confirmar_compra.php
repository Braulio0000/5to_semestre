<?php
session_start();
require_once 'funciones/conecta.php'; // Conexión a la base de datos

// Verificar si el usuario está logueado
if (!isset($_SESSION['idUser'])) {
    die("Debe estar logueado para confirmar la compra.");
}

// Calcular el total y actualizar stock
$total = 0;
if (isset($_SESSION['carrito']) && !empty($_SESSION['carrito'])) {
    $con = conecta();
    
    // Iniciar una transacción
    $con->begin_transaction();
    
    try {
        // Inserción en la tabla 'pedidos'
        $idCliente = $_SESSION['idUser'];
        $consultaPedido = $con->prepare("INSERT INTO pedidos (fecha, id_cliente, status) VALUES (NOW(), ?, 1)");
        $consultaPedido->bind_param("i", $idCliente);
        $consultaPedido->execute();
        $idPedido = $con->insert_id; // Obtener el ID del pedido insertado
        
        foreach ($_SESSION['carrito'] as $idProducto => $productoCarrito) {
            $cantidad = (int)$productoCarrito['cantidad'];

            // Obtener detalles del producto
            $consulta = $con->prepare("SELECT costo, stock FROM productos WHERE id = ?");
            $consulta->bind_param("i", $idProducto);
            $consulta->execute();
            $resultado = $consulta->get_result();
            $producto = $resultado->fetch_assoc();

            if ($producto) {
                $totalProducto = $producto['costo'] * $cantidad;
                $total += $totalProducto;

                // Actualizar stock
                $nuevoStock = $producto['stock'] - $cantidad;
                if ($nuevoStock >= 0) {
                    // Actualizar el stock del producto
                    $actualizarStock = $con->prepare("UPDATE productos SET stock = ? WHERE id = ?");
                    $actualizarStock->bind_param("ii", $nuevoStock, $idProducto);
                    $actualizarStock->execute();

                    // Inserción en la tabla 'pedidos_productos'
                    $insertPedidoProducto = $con->prepare("INSERT INTO pedidos_productos (id_pedido, id_producto, cantidad, costo) 
                                                           VALUES (?, ?, ?, ?)");
                    $insertPedidoProducto->bind_param("iiid", $idPedido, $idProducto, $cantidad, $producto['costo']);
                    $insertPedidoProducto->execute();
                } else {
                    throw new Exception("Stock insuficiente para el producto $idProducto.");
                }
            } else {
                throw new Exception("Producto no encontrado en la base de datos.");
            }
        }

        // Limpiar el carrito
        unset($_SESSION['carrito']);
        
        // Confirmar la transacción
        $con->commit();

    } catch (Exception $e) {
        // Si ocurre algún error, deshacer los cambios
        $con->rollback();
        die("Error durante la compra: " . $e->getMessage());
    }

} else {
    echo "El carrito está vacío.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compra Confirmada</title>
    <link rel="stylesheet" href="carritoEstilos.css">
</head>
<body>
<div class="container">
    <h1>¡Gracias por tu compra!</h1>
    <p>El total de tu compra es: $<?php echo number_format($total, 2); ?></p>
    <button onclick="window.location.href='index.php'">Volver a la página principal</button>
</div>
</body>
</html>
