<?php
$to = "christiancom@outlook.com"; // Cambia esto por el correo del destinatario
$subject = "Correo de prueba";
$message = "Hola, este es un correo enviado desde PHP usando Gmail.";
$headers = "From: christiancom2244@gmail.com";

if (mail($to, $subject, $message, $headers)) {
    echo "Correo enviado correctamente.";
} else {
    echo "Error al enviar el correo.";
}
?>
