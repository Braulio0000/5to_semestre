<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_logueado'])) {
    echo "Debes iniciar sesión para agregar productos al carrito.";
    exit();
}

// Obtener los datos del producto
$idProducto = $_POST['idProducto'];
$cantidad = $_POST['cantidad'];

// Verificar si el carrito ya existe en la sesión
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = array();
}

// Si el producto ya está en el carrito, sumamos la cantidad
if (isset($_SESSION['carrito'][$idProducto])) {
    $_SESSION['carrito'][$idProducto] += $cantidad;
} else {
    $_SESSION['carrito'][$idProducto] = $cantidad;
}

echo "Producto agregado al carrito con éxito.";
?>
