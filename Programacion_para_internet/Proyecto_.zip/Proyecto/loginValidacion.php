<?php
session_start();
require "funciones/conecta.php";
$con = conecta();

$correo = $_POST['correo'];
$pass = $_POST['pass'];


// Consultamos la base de datos para verificar si el usuario existe
$sql = "SELECT * FROM clientes WHERE correo = '$correo' AND pass = '$pass' AND eliminado = 0";
$res = $con->query($sql);

if ($res->num_rows > 0) {
    // Si el usuario es válido, creamos la sesión
    $row = $res->fetch_array();
    $_SESSION['idUser'] = $row['id'];
    $_SESSION['correoUser'] = $row['correo'];
    $_SESSION['nombreUser'] = $row['nombre'];
    echo 1; // Éxito en inicio de sesión
} else {
    echo 0; // Error en inicio de sesión
}
?>
