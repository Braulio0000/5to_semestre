<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = htmlspecialchars($_POST['nombre']);
    $correo = htmlspecialchars($_POST['email']);
    $mensaje = htmlspecialchars($_POST['mensaje']);

    // Correo del destinatario será el correo del cliente
    $to = $correo; // Enviamos el correo al cliente
    $subject = "Gracias por contactarnos";

    // Mensaje del correo, incluyendo el agradecimiento
    $body = "Gracias por contactarnos, $nombre.\n\n";
    $body .= "Hemos recibido el siguiente mensaje de tu parte:\n";
    $body .= "-------------------------\n";
    $body .= "Nombre: $nombre\nCorreo: $correo\nMensaje:\n$mensaje\n";
    $body .= "-------------------------\n";
    $body .= "\nTe responderemos lo antes posible.\n\n";
    $body .= "Saludos cordiales,\nEl equipo de soporte.";

    // Cabeceras para el correo
    $headers = "From: no-reply@tusitio.com\r\n"; // Cambia 'no-reply@tusitio.com' por tu correo
    $headers .= "Reply-To: no-reply@tusitio.com\r\n"; // Cambia según sea necesario

    // Intentar enviar el correo al cliente
    $enviado = mail($to, $subject, $body, $headers);

    // También enviar una copia al administrador (opcional)
    $to_admin = "christiancom2244@gmail.com"; // Cambia por tu correo
    $subject_admin = "Nuevo mensaje de contacto";
    $body_admin = "Tienes un nuevo mensaje de contacto:\n\n";
    $body_admin .= "Nombre: $nombre\nCorreo: $correo\nMensaje: $mensaje";

    // Enviar el correo a tu correo
    mail($to_admin, $subject_admin, $body_admin, $headers);

    // Respuesta JSON
    header('Content-Type: application/json');
    if ($enviado) {
        echo json_encode(['success' => true, 'message' => 'Correo enviado exitosamente. ¡Gracias por contactarnos!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al enviar el correo. Intente de nuevo más tarde.']);
    }
} else {
    // Respuesta si no es POST
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
}
?>
