<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['idUser'])) {
    die("Debe estar logueado para agregar productos al carrito.");
}

// Conexión a la base de datos
require_once 'funciones/conecta_productos.php'; // Usar require_once
$conexion = conecta();

// Verificar si la conexión es exitosa
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Obtener los datos del producto y la cantidad
$producto_id = isset($_GET['producto_id']) ? $_GET['producto_id'] : 0;
$cantidad = isset($_GET['cantidad']) ? (int)$_GET['cantidad'] : 0;

// Consultar el producto
$query = "SELECT * FROM productos WHERE id = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("i", $producto_id);
$stmt->execute();
$resultado = $stmt->get_result();
$producto = $resultado->fetch_assoc();

// Verificar si el producto existe y hay stock suficiente
if ($producto && $producto['stock'] >= $cantidad) {
    // Inicializar el carrito si no está definido
    if (!isset($_SESSION['carrito'])) {
        $_SESSION['carrito'] = [];
    }

    // Verificar si el producto ya está en el carrito y que sea un array
    if (isset($_SESSION['carrito'][$producto_id]) && is_array($_SESSION['carrito'][$producto_id])) {
        // Si el producto ya está en el carrito, incrementar la cantidad
        $_SESSION['carrito'][$producto_id]['cantidad'] += $cantidad;
    } else {
        // Si el producto no está en el carrito, añadirlo
        $_SESSION['carrito'][$producto_id] = [
            'producto_id' => $producto['id'],
            'nombre' => $producto['nombre'],
            'cantidad' => $cantidad,
            'costo' => $producto['costo']
        ];
    }

    // Redirigir al carrito o a una página de confirmación
    header('Location: carrito.php');
} else {
    echo "Producto no disponible o cantidad insuficiente.";
}

$stmt->close();
$conexion->close();
?>
