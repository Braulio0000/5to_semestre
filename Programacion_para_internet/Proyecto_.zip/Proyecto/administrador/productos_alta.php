<?php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alta de Productos</title>
  
  <link rel="stylesheet" href="estilos_formulario.css"> 
  <script src="js/jquery-3.3.1.min.js"></script> 
  
  <script> //aqui validamos si los campos estan llenos y si el codigo ya existe en la base de datos
    function validacion() {
      var nombre = $('#nombre').val();
      var codigo = $('#codigo').val();
      var descripcion = $('#descripcion').val();
      var costo = $('#costo').val();
      var stock = $('#stock').val();
      var codigoExiste = $('#codigoExiste').text().length > 0; //si el codigo ya esta en la base de datos mostramos un mensaje

      if (nombre === "" || codigo === "" || descripcion === "" || costo === "" || stock === "") {
        $('#mensaje').html("Faltan campos por llenar");
        setTimeout(function() {
          $('#mensaje').html('');
        }, 5000);
        return false; //pausar el boton enviar
      }
      
      if (codigoExiste) {
        alert("No se puede salvar porque el codigo ya existe.");
        return false; //evita que los datos se envien si el codigo esta duplicado
      }
      return true; //continua con la ejecucion si el codigo no esta duplicado
    }
    //funcion para validar codigo
    function validarCodigo() {
      //alert("sale del foco");
      var codigo = $('#codigo').val();
      $.ajax({
        url: 'validaCodigo.php', //archivo que valida el codigo
        type: 'POST',
        dataType : 'json',
        data: { codigo: codigo },
        success: function(response) {
          if (response >= 1) {
            //alert('si');
            $('#mensajeCodigo').html("El codigo " + codigo + " ya existe.");
            $('#codigo').val('');
          }
          setTimeout(() => { $('#mensajeCodigo').html(''); }, 5000);
        },error:function(){
          alert('Error archivo no encontrado');
        }
      });
    }
  </script>
</head>
<body>

    <div class="menu">
        <a href="bienvenido.php">INICIO</a>
        <a href="empleados_lista.php">EMPLEADOS</a>
        <a href="productos_lista.php">PRODUCTOS</a>
        <a href="promociones_lista.php">PROMOCIONES</a>
        <a href="pedidos.php">PEDIDOS</a>
        <a href="cerrarSesion.php">CERRAR SESIÓN</a>
    </div>

<div class="formulario-header">
    <h2 align="center">Alta de Productos</h2>
</div>  

<div class="formulario">
    <form align="center" name="forma01" method="post" action="productos_salva.php" enctype="multipart/form-data">
      <label for="nombre">Ingrese Nombre:</label><br>
      <input type="text" name="nombre" id="nombre" placeholder="Nombre del producto"/> <br>
      <label for="codigo">Ingrese Codigo:</label><br>
      <input onBlur="validarCodigo();" type="text" name="codigo" id="codigo" placeholder="0001"/> <br>
      <div id="mensajeCodigo" style="color: red;"></div><br>
      <label for="descripcion">Ingrese Descripcion:</label><br>
      <input type="text" name="descripcion" id="descripcion" placeholder="Añade una breve descripcion del producto"/> 
      <label for="costo">Ingrese Costo:</label><br>
      <input type="number" name="costo" id="costo" placeholder="Ingresa costo" /> <br>
      <label for="stock">Ingrese Stock</label><br>
      <input type="number" name="stock" id="stock" placeholder="Ingrese cantidad disponible">
    
      <br><br>
      <label for="foto">Foto del producto:</label>
      <input type="file" name="foto" id="foto" accept="image/*" required><br><br>
      <div id="mensaje"></div>
      <input onclick="return validacion()" type="submit" value="Guardar" />
    </form>
</div>

<div class="verLista"><a href="productos_lista.php">Ver lista de productos</a></div>

</body>
</html>
