<?php
require "funciones/conecta_productos.php"; //conectamos a la base de datos
$con = conecta();

//cachamos las variables del formulario
$nombre = $_POST['nombre'];
$codigo = $_POST['codigo'];
$descripcion = $_POST['descripcion'];
$costo = $_POST['costo'];
$stock = $_POST['stock'];

//nanejo de la imagen
$file_name = $_FILES['foto']['name'];
$file_tmp = $_FILES['foto']['tmp_name'];
$dir = "archivos_productos/";

//encriptamos el nombre de la imagen
$file_enc = md5_file($file_tmp) . "." . pathinfo($file_name, PATHINFO_EXTENSION);
if ($file_name) {
  copy($file_tmp, $dir . $file_enc);
} else {
        echo "Error al copiar el archivo.";
        exit();
}

//insertamos el empleado en la base de datos
$sql = "INSERT INTO productos (nombre, codigo, descripcion, costo, stock, archivo_n, archivo) 
        VALUES ('$nombre', '$codigo', '$descripcion', $costo, '$stock', '$file_name', '$file_enc')";
$res = $con->query($sql);

if (!$res) {
        echo "Error en la consulta SQL: " . $con->error;
        exit();
}

//redirigir al listado de empleados después de salvar
header("Location: productos_lista.php");
?>
