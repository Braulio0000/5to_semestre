<?php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alta de Empleados</title>
  
  <link rel="stylesheet" href="estilos_formulario.css"> 
  <script src="js/jquery-3.3.1.min.js"></script> 
  
  <script> //aqui validamos si los campos estan llenos y si el correo ya existe en la base de datos
    function validacion() {
      var nombre = $('#nombre').val();
      var apellidos = $('#apellidos').val();
      var correo = $('#correo').val();
      var pass = $('#pass').val();
      var rol = $('#rol').val();
      var correoExiste = $('#correoExiste').text().length > 0; //si el correo ya esta en la base de datos mostramos un mensaje

      if (nombre === "" || apellidos === "" || correo === "" || pass === "" || rol === "0") {
        $('#mensaje').html("Faltan campos por llenar");
        setTimeout(function() {
          $('#mensaje').html('');
        }, 5000);
        return false; //pausar el boton enviar
      }
      
      if (correoExiste) {
        alert("No se puede salvar porque el correo ya existe.");
        return false; //evita que los datos se envien si el correo esta duplicado
      }
      return true; //continua con la ejecucion si el correo no esta duplicado
    }
    //funcion para validar correo
    function validarCorreo() {
      //alert("sale del foco");
      var correo = $('#correo').val();
      $.ajax({
        url: 'validaCorreo.php', //archivo que valida el correo
        type: 'POST',
        dataType : 'text',
        data: "correo="+correo,
        success: function(response) {
          if (response >= 1) {
            //alert('si');
            $('#mensajeCorreo').html("El correo " + correo + " ya existe.");
            $('#correo').val('');
          }
          setTimeout("$('#mensajeCorreo').html('');",5000);
        },error:function(){
          alert('Error archivo no encontrado');
        }
      });
    }
  </script>
</head>
<body>

    <div class="menu">
        <a href="bienvenido.php">INICIO</a>
        <a href="empleados_lista.php">EMPLEADOS</a>
        <a href="productos_lista.php">PRODUCTOS</a>
        <a href="promociones_lista.php">PROMOCIONES</a>
        <a href="pedidos.php">PEDIDOS</a>
        <a href="cerrarSesion.php">CERRAR SESIÓN</a>
    </div>

<div class="formulario-header">
    <h2 align="center">Alta de Empleados</h2>
</div>  

<div class="formulario">
    <form align="center" name="forma01" method="post" action="empleados_salva.php" enctype="multipart/form-data">
      <label for="nombre">Ingrese Nombre:</label><br>
      <input type="text" name="nombre" id="nombre" placeholder="Juan"/> <br>
      <label for="apellidos">Ingrese Apellidos:</label><br>
      <input type="text" name="apellidos" id="apellidos" placeholder="Perez"/> <br>
      <label for="correo">Ingrese Correo Electrónico:</label><br>
      <input onBlur="validarCorreo();" type="text" name="correo" id="correo" placeholder="ejemplo@dominio.com"/> 
      <div id="mensajeCorreo"></div><br>
      <label for="pass">Ingrese clave de acceso:</label><br>
      <input type="password" name="pass" id="pass" placeholder="Escribe tu contraseña" /> <br>
      <label for="rol">Selecciona una opción:</label><br>
      <select name="rol" id="rol">
        <option value="0">Selecciona una opción</option>
        <option value="1">Gerente</option>
        <option value="2">Ejecutivo</option>
      </select>
      <br><br>
      <label for="foto">Foto del empleado:</label>
      <input type="file" name="foto" id="foto" accept="image/*" required><br><br>
      <div id="mensaje"></div>
      <input onclick="return validacion()" type="submit" value="Enviar" />
    </form>
</div>

<div class="verLista"><a href="empleados_lista.php">Ver lista de empleados</a></div>

</body>
</html>
