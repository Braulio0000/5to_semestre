<?php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
require "funciones/conecta_pedidos.php";
$con = conecta();

$sql = "SELECT * FROM pedidos WHERE status = 1";
$res = $con->query($sql);

// Verificar si la consulta fue exitosa
if (!$res) {
    // Si hay un error en la consulta, muestra el error
    echo "Error en la consulta SQL: " . $con->error;
    exit();
}

$num = $res->num_rows;

?>
<html>
  <head>
    <title>Modulo de Pedidos</title>
    <script src="js/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="estilosTabla.css">
  </head>
  <body>

    <div class="menu">
          <a href="bienvenido.php">INICIO</a>
          <a href="empleados_lista.php">EMPLEADOS</a>
          <a href="productos_lista.php">PRODUCTOS</a>
          <a href="promociones_lista.php">PROMOCIONES</a>
          <a href="cerrarSesion.php">CERRAR SESIÓN</a>
      </div>

    <div class="tabla">
        <h3>Lista de pedidos Cerrados (<?php echo $num ?>)</h3>
    </div>
    
    <div class="empleados">
      <div class="empleados-header">
        <div class="col">ID</div>
        <div class="col">Fecha</div>
        <div class="col">Opciones</div>
      </div>

      <?php
        while($row = $res->fetch_array()) {
            $id = $row["id"];
            $fecha = $row["fecha"];

            echo "<div class=\"pedidos-row\">";
            echo "<div class=\"col\">$id</div>";
            echo "<div class=\"col\">$fecha</div>";
            echo "<div class=\"col\">
                <a href=\"pedidos_ver_detalle.php?id=$id\">Ver detalle</a>
            </div>";
            echo "</div>";
        }
      ?>
  </div>

  </body>
</html>
