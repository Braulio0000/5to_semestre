<?php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
require "funciones/conecta.php";
$con = conecta();

$id = $_GET['id']; //tomamos el ID del empleado desde el botón Editar

//consultamos si el empleado existe o esta eliminado
$sql = "SELECT * FROM empleados WHERE id = $id AND eliminado = 0";
$res = $con->query($sql);
$row = $res->fetch_assoc();

if (!$row) {
    echo "Empleado no encontrado.";
    exit;
}

//variables para cargar los datos actuales del empleado
$nombre = $row['nombre'];
$apellidos = $row['apellidos'];
$correo = $row['correo'];
$rol = $row['rol'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Empleado</title>
    <link rel="stylesheet" href="estilos_editar.css">
    <script src="js/jquery-3.3.1.min.js"></script>
    <script>
    //guardamos el correo original en una variable al cargar la página
    const correoOriginal = $('#correo').val();

    function validarFormulario() {
        const nombre = $('#nombre').val();
        const apellidos = $('#apellidos').val();
        const correo = $('#correo').val();
        const rol = $('#rol').val();
        const correoExiste = $('#mensajeCorreo').text().length > 0; //verifica si el correo está repetido

        if (nombre === "" || apellidos === "" || correo === "" || rol === "0") {
            $('#mensaje').html("Faltan campos por llenar");
            setTimeout(() => $('#mensaje').html(''), 5000);
            return false;
        }

        if (correoExiste) {
            $('#mensaje').html("No se puede actualizar porque el correo ya existe.");
            setTimeout(() => $('#mensaje').html(''), 5000);
            return false;
        }

        return true; 
    }

    function validarCorreo() {
        const correo = $('#correo').val();
        const id = <?php echo $id; ?>; //ID actual para evitar validar su propio correo

        $.ajax({
            url: 'validaCorreo_editar.php',
            type: 'POST',
            dataType: 'text',
            data: { correo: correo, id: id },
            success: function(response) {
                if (response >= 1) {
                    $('#mensajeCorreo').html("El correo " + correo + " ya existe.");
                    setTimeout(() => $('#mensajeCorreo').html(''), 5000);

                    //restablecer el campo de correo al valor original
                    $('#correo').val(correoOriginal);
                }
            },
            error: function() {
                alert('Error al validar el correo.');
            }
        });
    }
    </script>
</head>
<body>

    <div class="menu">
        <a href="bienvenido.php">INICIO</a>
        <a href="empleados_lista.php">EMPLEADOS</a>
        <a href="productos_lista.php">PRODUCTOS</a>
        <a href="promociones_lista.php">PROMOCIONES</a>
        <a href="pedidos.php">PEDIDOS</a>
        <a href="cerrarSesion.php">CERRAR SESIÓN</a>
    </div>

<div class="formulario-editar">
        <h2>Edición de empleados</h2>

        <form method="post" action="empleados_actualizar.php" enctype="multipart/form-data" onsubmit="return validarFormulario()">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo $nombre; ?>" required>
            <label for="apellidos">Apellidos:</label>
            <input type="text" id="apellidos" name="apellidos" value="<?php echo $apellidos; ?>" required>
            <label for="correo">Correo:</label>
            <input type="email" id="correo" name="correo" value="<?php echo $correo; ?>" onBlur="validarCorreo();" required>
            <div id="mensajeCorreo" style="color: red;"></div>
            <label for="pass">Nueva Contraseña (opcional):</label>
            <input type="password" id="pass" name="pass">
            <label for="rol">Rol:</label>
            <select id="rol" name="rol" required>
                <option value="0">Selecciona una opción</option>
                <option value="1" <?php if ($rol == 1) echo "selected"; ?>>Gerente</option>
                <option value="2" <?php if ($rol == 2) echo "selected"; ?>>Ejecutivo</option>
            </select>
            <label for="foto">Cambiar Foto:</label>
            <input type="file" name="foto" id="foto" accept="image/*">
            <div id="mensaje" style="color: red;"></div>
            <button type="submit">Actualizar</button>
        </form>
        <div align="center"><a href="empleados_lista.php" class="regresar">Regresar al listado de empleados</a></div>
    </div>
</body>
</html>
