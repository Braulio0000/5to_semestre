<?php
require "funciones/conecta.php";
$con = conecta();

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$correo = $_POST['correo'];
$pass = $_POST['pass'];
$rol = $_POST['rol'];

$sqlPass = $pass ? ", pass = '" . md5($pass) . "'" : ""; //aqui encriptamos si es que ingreso nuevo conatrasna

//nombre temporal de la imagen para cuando suba una nueva foto
$file_name = $_FILES['foto']['name'];
$file_tmp = $_FILES['foto']['tmp_name'];
$dir = "archivos/";
$fotoQuery = "";

//si el usuario selecciona una nueva imagen para subir
if ($file_name != '') {
    $file_enc = md5_file($file_tmp); //nombre encriptado del archivo
    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
    $fileName1 = "$file_enc.$file_ext";

    //gardamos la imagen en la carpeta de archivos
    move_uploaded_file($file_tmp, $dir . $fileName1);

    //preparamos los campos de actualización para la imagen
    $sqlImage = ", archivo_n = '$file_name', archivo = '$fileName1'";
} else {
    $sqlImage = "";
}

//actualización en la base de datos, insertamos
$sql = "UPDATE empleados 
        SET nombre = '$nombre', apellidos = '$apellidos', correo = '$correo', rol = $rol $sqlPass $sqlImage 
        WHERE id = $id";
$res = $con->query($sql);

if ($res) {
    echo "<script>window.location.href = 'empleados_lista.php';</script>";
} else {
    echo "Error al actualizar los datos del empleado.";
}
?>