<?php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alta de Promociones</title>
  
  <link rel="stylesheet" href="estilos_formulario.css"> 
  <script src="js/jquery-3.3.1.min.js"></script> 
  
  <script> //aqui validamos si los campos estan llenos y si el nombre ya existe en la base de datos
    function validacion() {
      var nombre = $('#nombre').val();
      var nombreExiste = $('#nombreExiste').text().length > 0; //si el nombre ya esta en la base de datos mostramos un mensaje

      if (nombre === "") {
        $('#mensaje').html("Faltan campos por llenar");
        setTimeout(function() {
          $('#mensaje').html('');
        }, 5000);
        return false; //pausar el boton enviar
      }
      
      if (nombreExiste) {
        alert("No se puede salvar porque el nombre ya existe.");
        return false; //evita que los datos se envien si el codigo esta duplicado
      }
      return true; //continua con la ejecucion si el codigo no esta duplicado
    }
    //funcion para validar codigo
    function validarNombre() {
      //alert("sale del foco");
      var nombre = $('#nombre').val();
      $.ajax({
        url: 'validaNombre.php', //archivo que valida el codigo
        type: 'POST',
        dataType : 'json',
        data: { nombre: nombre },
        success: function(response) {
          if (response >= 1) {
            //alert('si');
            $('#mensajeNombre').html("El nombre " + nombre + " para esta promcion ya existe.");
            $('#nombre').val('');
          }
          setTimeout(() => { $('#mensajeNombre').html(''); }, 5000);
        },error:function(){
          alert('Error archivo no encontrado');
        }
      });
    }
  </script>
</head>
<body>

    <div class="menu">
        <a href="bienvenido.php">INICIO</a>
        <a href="empleados_lista.php">EMPLEADOS</a>
        <a href="productos_lista.php">PRODUCTOS</a>
        <a href="promociones_lista.php">PROMOCIONES</a>
        <a href="pedidos.php">PEDIDOS</a>
        <a href="cerrarSesion.php">CERRAR SESIÓN</a>
    </div>

<div class="formulario-header">
    <h2 align="center">Alta de Promocines</h2>
</div>  

<div class="formulario">
    <form align="center" name="forma01" method="post" action="promociones_salva.php" enctype="multipart/form-data">
      <label for="nombre">Ingrese Nombre:</label><br>
      <input onBlur="validarNombre();" type="text" name="nombre" id="nombre" placeholder="Nombre del producto"/> <br>
      <div id="mensajeNombre" style="color: red;"></div><br>
      
      <br><br>
      <label for="foto">Foto del producto:</label>
      <input type="file" name="foto" id="foto" accept="image/*" required><br><br>
      <div id="mensaje"></div>
      <input onclick="return validacion()" type="submit" value="Guardar" />
    </form>
</div>

<div class="verLista"><a href="promociones_lista.php">Ver lista de promociones</a></div>

</body>
</html>
