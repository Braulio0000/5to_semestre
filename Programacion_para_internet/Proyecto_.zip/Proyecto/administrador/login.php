<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="estilos_login.css">
    <script src="js/jquery-3.3.1.min.js"></script>
    <script>
        //validacion de campos llenos
        function validarFormulario() {
            var correo = $('#correo').val();
            var pass = $('#pass').val();
            
            if (correo === "" || pass === "") {
                $('#mensaje').html("Todos los campos son obligatorios.");
                setTimeout(function() { $('#mensaje').html(''); }, 5000);
                return false;
            }

            //implementamos AJAX para enviar datos
            $.ajax({
                url: 'validacionLogin.php',
                type: 'POST',
                data: { correo: correo, pass: pass },
                success: function(response) {
                    if (response == 1) {
                        window.location.href = 'bienvenido.php'; //redireccionamos con javascript
                    } else {
                        $('#mensaje').html("Usuario o contraseña incorrectos.");
                    }
                }
            });
        }
    </script>
</head>
<body>
    <h2>Iniciar sesión</h2>
    <form onsubmit="event.preventDefault(); validarFormulario();">
        <label for="correo">Correo:</label>
        <input type="text" id="correo" name="correo"><br>
        
        <label for="pass">Contraseña:</label>
        <input type="password" id="pass" name="pass"><br>
        
        <button type="submit">Ingresar</button>
        
        <div id="mensaje" style="color: red;"></div>
    </form>
    
</body>
</html>
