<?php
//promociones_ver_detalle.php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
require "funciones/conecta_promociones.php";
$con = conecta();

//captura el ID del producto
$id = $_GET['id'];
    
//consulta para obtener los datos de la promocion
$sql = "SELECT nombre, archivo FROM promociones WHERE id = $id AND eliminado = 0";
$res = $con->query($sql);

if ($res && $res->num_rows > 0) {
    $row = $res->fetch_assoc();
    $nombre = $row['nombre'];
} else {
    echo "Promocion no encontrada.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalles</title>
    <link rel="stylesheet" href="estilos_ver_detalle.css">
</head>
<body>

    <div class="menu">
        <a href="bienvenido.php">INICIO</a>
        <a href="empleados_lista.php">EMPLEADOS</a>
        <a href="productos_lista.php">PRODUCTOS</a>
        <a href="promociones_lista.php">PROMOCIONES</a>
        <a href="pedidos.php">PEDIDOS</a>
        <a href="cerrarSesion.php">CERRAR SESIÓN</a>
    </div>

    <h2>Datos de la Promocion</h2>
    <div class="detalle-empleado">
        <p><strong>Nombre:</strong> <?php echo $nombre; ?></p>
        <p><strong>Foto:</strong><br>
            <img src="archivos_promociones/<?php echo $row['archivo']; ?>" alt="Foto de <?php echo $row['nombre']; ?>" width="400" height="170">
        </p>
    </div>
    <div class="regresar">
        <a href="promociones_lista.php">Regresar al listado</a>
    </div>
</body>
</html>
