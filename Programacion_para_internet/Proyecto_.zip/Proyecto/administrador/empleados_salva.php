<?php
require "funciones/conecta.php"; //conectamos a la base de datos
$con = conecta();

//cachamos las variables del formulario
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$correo = $_POST['correo'];
$pass = $_POST['pass'];
$rol = $_POST['rol'];

//nanejo de la imagen
$file_name = $_FILES['foto']['name'];
$file_tmp = $_FILES['foto']['tmp_name'];
$dir = "archivos/";

//encriptamos el nombre de la imagen
$file_enc = md5_file($file_tmp) . "." . pathinfo($file_name, PATHINFO_EXTENSION);
if ($file_name) {
  copy($file_tmp, $dir . $file_enc);
} else {
        echo "Error al copiar el archivo.";
        exit();
}

//metodo para encriptar la contraseña
$passEnc = md5($pass);

//insertamos el empleado en la base de datos
$sql = "INSERT INTO empleados (nombre, apellidos, correo, rol, pass, archivo_n, archivo) 
        VALUES ('$nombre', '$apellidos', '$correo', $rol, '$passEnc', '$file_name', '$file_enc')";
$res = $con->query($sql);

if (!$res) {
        echo "Error en la consulta SQL: " . $con->error;
        exit();
}

//redirigir al listado de empleados después de salvar
header("Location: empleados_lista.php");
?>
