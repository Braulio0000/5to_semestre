<?php
//empleados_lista.php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
require "funciones/conecta.php";
$con = conecta();

$sql = "SELECT * FROM empleados WHERE eliminado = 0";
$res = $con->query($sql);
$num = $res->num_rows;

?>
<html>
  <head>
    <title>Modulo de empleados</title>
    <script src="js/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="estilosTabla.css">
  </head>
  <body>

    <div class="menu">
          <a href="bienvenido.php">INICIO</a>
          <a href="productos_lista.php">PRODUCTOS</a>
          <a href="promociones_lista.php">PROMOCIONES</a>
          <a href="pedidos.php">PEDIDOS</a>
          <a href="cerrarSesion.php">CERRAR SESIÓN</a>
      </div>
    <div class="tabla">Lista de Empleados (<?php echo $num?>)</div>
    <div class="container"> 
      <div class="nuevo"> 
        <a href="empleados_alta.php" class="boton">CREAR UN NUEVO EMPLEADO</a> 
      </div> 
    </div>
  
    <div class="empleados">
      <div class="empleados-header">
        <div class="col">ID</div>
        <div class="col">Nombre y apellido</div>
        <div class="col">Correo</div>
        <div class="col">Rol</div>
        <div class="col">Opciones</div>
      </div>

    <?php
      while($row = $res->fetch_array()) {
      $id = $row["id"];
      $nombre = $row["nombre"].' '.$row["apellidos"];
      $correo = $row["correo"];
      $pass = $row["pass"];
      $rol = $row["rol"];
      $rol_text = ($rol == 1) ? 'Gerente' : 'Ejecutivo';

      //modificamos el enlace con el nuevo archivo para hacer la actualizacion al momento de eliminar
      echo "<div class=\"empleados-row\" id=\"empleado_$id\">";
      echo "<div class=\"col\">$id</div>";
      echo "<div class=\"col\">$nombre</div>";
      echo "<div class=\"col\">$correo</div>";
      echo "<div class=\"col\">$rol_text</div>";
      echo "<div class=\"col\">
        <a href=\"empleados_ver_detalle.php?id=$id\">Ver detalle</a> |
        <a href=\"editar.php?id=$id\">Editar</a> |
        <a href=\"javascript:void(0);\" onclick=\"eliminarEmpleado($id)\">Eliminar</a>
      </div>";
      echo "</div>";
    }
    ?>
  </div>
  
  <script> //funcion de javascript para confirmar eliminacion del empleado
    function eliminarEmpleado(id) {
      if (confirm('¿Estás seguro de que deseas eliminar este empleado?')) {
        $.ajax({
          url: 'empleados_eliminar.php',
          type: 'POST',
          data: { id: id },
          success: function(response) {
            if (response == 1) {
              $('#empleado_' + id).remove();
              alert('Empleado eliminado correctamente');
            } else {
              alert('Error al eliminar el empleado');
            }
          }
        });
      }
    }
  </script>
  
  </body>
</html>
  