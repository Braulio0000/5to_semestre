<?php
//empleados_eliminar.php
require "funciones/conecta.php";
$con = conecta();

$id = $_POST['id'];  //aqui recibimos el id que nos envia ajax
//aqui cambiamos la bandera para marcar al empleado como eliminado 
$sql = "UPDATE empleados SET eliminado = 1 WHERE id = $id";
$res = $con->query($sql);

//verificamos si la consulta se realizo correctamente
if ($res) {
    echo 1;  //1 para marcar como eliminado
} else {
    echo 0;  //0 por si hubo un error
}
?>
