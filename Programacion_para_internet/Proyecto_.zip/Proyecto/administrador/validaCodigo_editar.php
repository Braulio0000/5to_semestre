<?php
require "funciones/conecta_productos.php";
$con = conecta();

$codigo = $_POST['codigo'];
$id = $_POST['id'];

//validamos el codigo pero excluimos el nuestro para evitar conflictos
$sql = "SELECT COUNT(*) FROM productos WHERE codigo = '$codigo' AND id != $id";
$res = $con->query($sql);
$row = $res->fetch_row();

echo $row[0]; //devolvemos el numero de coincidencias (0 si no existe, 1 si existe)
?>
