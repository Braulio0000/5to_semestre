<?php
require "funciones/conecta.php";
$con = conecta();

$correo = $_POST['correo'];
$id = $_POST['id'];

//validamos el correo pero excluimos el nuestro para evitar conflictos
$sql = "SELECT COUNT(*) FROM empleados WHERE correo = '$correo' AND id != $id";
$res = $con->query($sql);
$row = $res->fetch_row();

echo $row[0]; //devolvemos el numero de coincidencias (0 si no existe, 1 si existe)
?>
