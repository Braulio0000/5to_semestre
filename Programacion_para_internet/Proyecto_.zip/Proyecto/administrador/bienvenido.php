<?php
session_start();

// Verificamos si el usuario ha iniciado sesión
if (!isset($_SESSION['nombreUser'])) {
    // Redirigimos al login si no está autenticado
    header("Location: login.php");
    exit();
}

// Obtenemos la variable de sesión
$nombreUser = $_SESSION['nombreUser'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Bienvenido</title>
    <link rel="stylesheet" href="bienvenido.css">  
</head>
<body>
<div class="container">
    <h2>Bienvenido al sistema</h2>
    <div class="welcome-message">Hola <?php echo $nombreUser;?>, ¡nos alegra verte!</div>
    
    <div class="menu">
        <a href="bienvenido.php">INICIO</a>
        <a href="empleados_lista.php">EMPLEADOS</a>
        <a href="productos_lista.php">PRODUCTOS</a>
        <a href="promociones_lista.php">PROMOCIONES</a>
        <a href="pedidos.php">PEDIDOS</a>
        <a href="cerrarSesion.php">CERRAR SESIÓN</a>
    </div>
    
    <h5>© Todos los derechos reservados</h5>
</div>

</body>
</html>
