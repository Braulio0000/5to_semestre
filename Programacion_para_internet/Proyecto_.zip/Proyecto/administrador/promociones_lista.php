<?php
//promociones_lista.php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
require "funciones/conecta_promociones.php";
$con = conecta();

$sql = "SELECT * FROM promociones WHERE eliminado = 0";
$res = $con->query($sql);
$num = $res->num_rows;

?>
<html>
  <head>
    <title>Modulo de promociones</title>
    <script src="js/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="estilosTabla.css">
  </head>
  <body>

    <div class="menu">
          <a href="bienvenido.php">INICIO</a>
          <a href="empleados_lista.php">EMPLEADOS</a>
          <a href="productos_lista.php">PRODUCTOS</a>
          <a href="pedidos.php">PEDIDOS</a>
          <a href="cerrarSesion.php">CERRAR SESIÓN</a>
      </div>
    <div class="tabla">Lista de Promociones (<?php echo $num?>)</div>
    <div class="container"> 
      <div class="nuevo"> 
        <a href="promociones_alta.php" class="boton">AGREGAR NUEVA PROMOCION</a> 
      </div> 
    </div>
  
    <div class="empleados">
      <div class="empleados-header">
        <div class="col">ID</div>
        <div class="col">Nombre</div>
        <div class="col">Opciones</div>
      </div>

    <?php
      while($row = $res->fetch_array()) {
      $id = $row["id"];
      $nombre = $row["nombre"];

      //modificamos el enlace con el nuevo archivo para hacer la actualizacion al momento de eliminar
      echo "<div class=\"empleados-row\" id=\"promociones_$id\">";
      echo "<div class=\"col\">$id</div>";
      echo "<div class=\"col\">$nombre</div>";
      echo "<div class=\"col\">
        <a href=\"promociones_ver_detalle.php?id=$id\">Ver detalle</a> |
        <a href=\"promociones_editar.php?id=$id\">Editar</a> |
        <a href=\"javascript:void(0);\" onclick=\"eliminarPromocion($id)\">Eliminar</a>
      </div>";
      echo "</div>";
    }
    ?>
  </div>

  <script> //funcion de javascript para confirmar eliminacion de una promocion
    function eliminarPromocion(id) {
      if (confirm('¿Estás seguro de que deseas eliminar esta promocion?')) {
        $.ajax({
          url: 'promociones_eliminar.php',
          type: 'POST',
          data: { id: id },
          success: function(response) {
            if (response == 1) {
              $('#promociones_' + id).remove();
              alert('Promocion eliminada correctamente');
            } else {
              alert('Error al eliminar la promocion');
            }
          }
        });
      }
    }
  </script>
  
  </body>
</html>
  