<?php
require "funciones/conecta_promociones.php";
$con = conecta();

$nombre = $_POST['nombre'];
$id = $_POST['id'];

//validamos el nombre pero excluimos el nuestro para evitar conflictos
$sql = "SELECT COUNT(*) FROM promociones WHERE nombre = '$nombre' AND id != $id";
$res = $con->query($sql);
$row = $res->fetch_row();

echo $row[0]; //devolvemos el numero de coincidencias (0 si no existe, 1 si existe)
?>
