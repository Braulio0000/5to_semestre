<?php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
require "funciones/conecta_promociones.php";
$con = conecta();

$id = $_GET['id']; //tomamos el ID de la promo desde el botón Editar

//consultamos si el producto existe o esta eliminado
$sql = "SELECT * FROM promociones WHERE id = $id AND eliminado = 0";
$res = $con->query($sql);
$row = $res->fetch_assoc();

if (!$row) {
    echo "Promo no encontrada.";
    exit;
}

//variables para cargar los datos actuales de la promo
$nombre = $row['nombre'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Promo</title>
    <link rel="stylesheet" href="estilos_editar.css">
    <script src="js/jquery-3.3.1.min.js"></script>
    <script>
    //guardamos el nombre original en una variable al cargar la página
    const nombreOriginal = $('#nombre').val();

    function validarFormulario() {
        const nombre = $('#nombre').val();
        const nombreExiste = $('#mensajeNombre').text().length > 0; //verifica si el nombre está repetido

        if (nombre === "") {
            $('#mensaje').html("Faltan campos por llenar");
            setTimeout(() => $('#mensaje').html(''), 5000);
            return false;
        }

        if (nombreExiste) {
            $('#mensaje').html("No se puede actualizar porque el nombre ya existe.");
            setTimeout(() => $('#mensaje').html(''), 5000);
            return false;
        }

        return true; 
    }

    function validarNombre() {
        const nombre = $('#nombre').val();
        const id = <?php echo $id; ?>; //ID actual para evitar validar su propio nombre

        $.ajax({
            url: 'validaNombre_editar.php',
            type: 'POST',
            dataType: 'json',
            data: { nombre: nombre, id: id },
            success: function(response) {
                if (response >= 1) {
                    $('#mensajeNombre').html("El nombre " + nombre + " ya existe.");
                    setTimeout(() => $('#mensajeCodigo').html(''), 5000);

                    //restablecer el campo de codigo al valor original
                    $('#nombre').val(nombreOriginal);
                }
            },
            error: function() {
                alert('Error al validar el nombre.');
            }
        });
    }
    </script>
</head>
<body>

    <div class="menu">
        <a href="bienvenido.php">INICIO</a>
        <a href="empleados_lista.php">EMPLEADOS</a>
        <a href="productos_lista.php">PRODUCTOS</a>
        <a href="promociones_lista.php">PROMOCIONES</a>
        <a href="pedidos.php">PEDIDOS</a>
        <a href="cerrarSesion.php">CERRAR SESIÓN</a>
    </div>

<div class="formulario-editar">
        <h2>Edición de promociones</h2>

          <form method="post" action="promociones_actualizar.php" enctype="multipart/form-data" onsubmit="return validarFormulario()">
              <input type="hidden" name="id" value="<?php echo $id; ?>">
              <label for="nombre">Nombre:</label>
              <input onBlur="validarNombre();" type="text" name="nombre" id="nombre" value="<?php echo $nombre; ?>"  required>
              <div id="mensajeNombre" style="color: red;"></div>
              <label for="foto">Cambiar Foto (opcional)</label>
              <input type="file" name="foto" id="foto" accept="image/*">
              <div id="mensaje" style="color: red;"></div>
              <button type="submit">Actualizar</button>
          </form>
        <div align="center"><a href="promociones_lista.php" class="regresar">Regresar al listado de promociones</a></div>
    </div>
</body>
</html>
