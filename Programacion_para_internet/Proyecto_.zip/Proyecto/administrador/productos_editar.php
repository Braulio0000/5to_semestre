<?php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
require "funciones/conecta_productos.php";
$con = conecta();

$id = $_GET['id']; //tomamos el ID del producto desde el botón Editar

//consultamos si el producto existe o esta eliminado
$sql = "SELECT * FROM productos WHERE id = $id AND eliminado = 0";
$res = $con->query($sql);
$row = $res->fetch_assoc();

if (!$row) {
    echo "Producto no encontrado.";
    exit;
}

//variables para cargar los datos actuales del producto
$nombre = $row['nombre'];
$codigo = $row['codigo'];
$descripcion = $row['descripcion'];
$costo = $row['costo'];
$stock = $row['stock'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Producto</title>
    <link rel="stylesheet" href="estilos_editar.css">
    <script src="js/jquery-3.3.1.min.js"></script>
    <script>
    //guardamos el correo original en una variable al cargar la página
    const codigoOriginal = $('#codigo').val();

    function validarFormulario() {
        const nombre = $('#nombre').val();
        const codigo = $('#codigo').val();
        const descripcion = $('#descripcion').val();
        const costo = $('#costo').val();
        const stock = $('#stock').val();
        const codigoExiste = $('#mensajeCodigo').text().length > 0; //verifica si el codigo está repetido

        if (nombre === "" || codigo === "" || descripcion === "" || costo === "" || stock === "") {
            $('#mensaje').html("Faltan campos por llenar");
            setTimeout(() => $('#mensaje').html(''), 5000);
            return false;
        }

        if (codigoExiste) {
            $('#mensaje').html("No se puede actualizar porque el codigo ya existe.");
            setTimeout(() => $('#mensaje').html(''), 5000);
            return false;
        }

        return true; 
    }

    function validarCodigo() {
        const codigo = $('#codigo').val();
        const id = <?php echo $id; ?>; //ID actual para evitar validar su propio codigo

        $.ajax({
            url: 'validaCodigo_editar.php',
            type: 'POST',
            dataType: 'json',
            data: { codigo: codigo, id: id },
            success: function(response) {
                if (response >= 1) {
                    $('#mensajeCodigo').html("El codigo " + codigo + " ya existe.");
                    setTimeout(() => $('#mensajeCodigo').html(''), 5000);

                    //restablecer el campo de codigo al valor original
                    $('#codigo').val(codigoOriginal);
                }
            },
            error: function() {
                alert('Error al validar el codigo.');
            }
        });
    }
    </script>
</head>
<body>

    <div class="menu">
        <a href="bienvenido.php">INICIO</a>
        <a href="empleados_lista.php">EMPLEADOS</a>
        <a href="productos_lista.php">PRODUCTOS</a>
        <a href="promociones_lista.php">PROMOCIONES</a>
        <a href="pedidos.php">PEDIDOS</a>
        <a href="cerrarSesion.php">CERRAR SESIÓN</a>
    </div>

<div class="formulario-editar">
        <h2>Edición de productos</h2>

          <form method="post" action="productos_actualizar.php" enctype="multipart/form-data" onsubmit="return validarFormulario()">
              <input type="hidden" name="id" value="<?php echo $id; ?>">
              <label for="nombre">Nombre:</label>
              <input type="text" id="nombre" name="nombre" value="<?php echo $nombre; ?>" required>
              <label for="codigo">Codigo:</label>
              <input onBlur="validarCodigo();" type="text" name="codigo" id="codigo" value="<?php echo $codigo; ?>"  required>
              <div id="mensajeCodigo" style="color: red;"></div>
              <label for="descripcion">Descripcion:</label>
              <input type="text" id="descripcion" name="descripcion" value="<?php echo $descripcion; ?>" required>
              <label for="costo">Costo:</label>
              <input type="number" id="costo" name="costo" value="<?php echo $costo; ?>" required>
              <label for="stock">Stock:</label>
              <input type="number" id="stock" name="stock" value="<?php echo $stock; ?>" required>
              <label for="foto">Cambiar Foto (opcional)</label>
              <input type="file" name="foto" id="foto" accept="image/*">
              <div id="mensaje" style="color: red;"></div>
              <button type="submit">Actualizar</button>
          </form>
        <div align="center"><a href="productos_lista.php" class="regresar">Regresar al listado de productos</a></div>
    </div>
</body>
</html>
