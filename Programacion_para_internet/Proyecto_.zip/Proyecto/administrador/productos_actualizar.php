<?php
require "funciones/conecta_productos.php";
$con = conecta();

// Validar conexión 
if ($con->connect_error) { 
  die("Error en la conexión: " . $con->connect_error); 
}

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$codigo = $_POST['codigo'];
$descripcion = $_POST['descripcion'];
$costo = $_POST['costo'];
$stock = $_POST['stock'];

//nombre temporal de la imagen para cuando suba una nueva foto
$file_name = $_FILES['foto']['name'];
$file_tmp = $_FILES['foto']['tmp_name'];
$dir = "archivos_productos/";
$fotoQuery = "";

//si el usuario selecciona una nueva imagen para subir
if ($file_name != '') {
    $file_enc = md5_file($file_tmp); //nombre encriptado del archivo
    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
    $fileName1 = "$file_enc.$file_ext";

    //gardamos la imagen en la carpeta de archivos
    if (move_uploaded_file($file_tmp, $dir . $fileName1)) {
      //preparamos los campos de actualización para la imagen
      $sqlImage = ", archivo_n = '$file_name', archivo = '$fileName1'";
    } else {
        die("Error al subir la imagen.");
    }
} else {
  $sqlImage = "";
}

// Construcción de la consulta SQL 
$sql = "UPDATE productos 
        SET nombre = '$nombre', codigo = '$codigo', descripcion = '$descripcion', costo = '$costo', stock = '$stock' $sqlImage WHERE id = $id";

// Ejecutar consulta y registrar error si falla 
if ($con->query($sql) === TRUE) {
   echo "<script>window.location.href = 'productos_lista.php';</script>"; 
} else {
   echo "Error al actualizar los datos del producto: " . $con->error; 
}

$con->close();
?>