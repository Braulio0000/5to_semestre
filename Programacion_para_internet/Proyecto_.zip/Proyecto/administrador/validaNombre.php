<?php
require "funciones/conecta_promociones.php";
$con = conecta();

$nombre = $_POST['nombre'];
$id = isset($_POST['id']) ? $_POST['id'] : 0; // Si no hay id, asumir que es un nuevo producto

//validamos el codigo, excluyendo el nuestro en caso de edición
$sql = "SELECT COUNT(*) as count FROM promociones WHERE nombre = '$nombre' AND id != $id AND eliminado = 0";
$res = $con->query($sql);
$row = $res->fetch_assoc();

echo json_encode($row['count']);
?>
