<?php
//empleados_lista.php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
require "funciones/conecta_productos.php";
$con = conecta();

$sql = "SELECT * FROM productos WHERE eliminado = 0";
$res = $con->query($sql);
$num = $res->num_rows;

?>
<html>
  <head>
    <title>Modulo de productos</title>
    <script src="js/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="estilosTabla.css">
  </head>
  <body>

    <div class="menu">
          <a href="bienvenido.php">INICIO</a>
          <a href="empleados_lista.php">EMPLEADOS</a>
          <a href="promociones_lista.php">PROMOCIONES</a>
          <a href="pedidos.php">PEDIDOS</a>
          <a href="cerrarSesion.php">CERRAR SESIÓN</a>
      </div>
    <div class="tabla">Lista de Productos (<?php echo $num?>)</div>
    <div class="container"> 
      <div class="nuevo"> 
        <a href="productos_alta.php" class="boton">DAR DE ALTA UN NUEVO PRODUCTO</a> 
      </div> 
    </div>
  
    <div class="empleados">
      <div class="empleados-header">
        <div class="col">ID</div>
        <div class="col">Nombre</div>
        <div class="col">Codigo</div>
        <div class="col">Descripcion</div>
        <div class="col">Costo</div>
        <div class="col">Stock</div>
        <div class="col">Opciones</div>
      </div>

    <?php
      while($row = $res->fetch_array()) {
      $id = $row["id"];
      $nombre = $row["nombre"];
      $codigo = $row["codigo"];
      $descripcion = $row["descripcion"];
      $costo = $row["costo"];
      $stock = $row["stock"];

      //modificamos el enlace con el nuevo archivo para hacer la actualizacion al momento de eliminar
      echo "<div class=\"empleados-row\" id=\"producto_$id\">";
      echo "<div class=\"col\">$id</div>";
      echo "<div class=\"col\">$nombre</div>";
      echo "<div class=\"col\">$codigo</div>";
      echo "<div class=\"col\">$descripcion</div>";
      echo "<div class=\"col\">$ $costo</div>";
      echo "<div class=\"col\">$stock</div>";
      echo "<div class=\"col\">
        <a href=\"productos_ver_detalle.php?id=$id\">Ver detalle</a> |
        <a href=\"productos_editar.php?id=$id\">Editar</a> |
        <a href=\"javascript:void(0);\" onclick=\"eliminarProducto($id)\">Eliminar</a>
      </div>";
      echo "</div>";
    }
    ?>
  </div>

  <script> //funcion de javascript para confirmar eliminacion del producto
    function eliminarProducto(id) {
      if (confirm('¿Estás seguro de que deseas eliminar este producto?')) {
        $.ajax({
          url: 'productos_eliminar.php',
          type: 'POST',
          data: { id: id },
          success: function(response) {
            if (response == 1) {
              $('#producto_' + id).remove();
              alert('Producto eliminado correctamente');
            } else {
              alert('Error al eliminar el producto');
            }
          }
        });
      }
    }
  </script>
  
  </body>
</html>
  