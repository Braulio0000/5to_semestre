<?php
require "funciones/conecta.php"; //conexión a la base de datos
$con = conecta();

$correo = $_REQUEST['correo'];

$sql = "SELECT * FROM empleados WHERE eliminado = 0 AND correo = '$correo'";
$res = $con->query($sql);
$num = $res->num_rows;

echo $num; //retorna 1 si el correo ya existe, 0 si no existe
?>
