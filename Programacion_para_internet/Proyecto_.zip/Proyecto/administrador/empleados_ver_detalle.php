<?php
//empleados_ver_detalle.php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
require "funciones/conecta.php";
$con = conecta();

//captura el ID del empleado
$id = $_GET['id'];

//consulta para obtener los datos del empleado
$sql = "SELECT nombre, apellidos, correo, rol, archivo FROM empleados WHERE id = $id AND eliminado = 0";
$res = $con->query($sql);

if ($res && $res->num_rows > 0) {
    $row = $res->fetch_assoc();
    $nombreCompleto = $row['nombre'] . ' ' . $row['apellidos'];
    $correo = $row['correo'];
    $rol = $row['rol'] == 1 ? 'Gerente' : 'Ejecutivo';
} else {
    echo "Empleado no encontrado.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle de Empleado</title>
    <link rel="stylesheet" href="estilos_ver_detalle.css">
</head>
<body>

    <div class="menu">
        <a href="bienvenido.php">INICIO</a>
        <a href="empleados_lista.php">EMPLEADOS</a>
        <a href="productos_lista.php">PRODUCTOS</a>
        <a href="promociones_lista.php">PROMOCIONES</a>
        <a href="pedidos.php">PEDIDOS</a>
        <a href="cerrarSesion.php">CERRAR SESIÓN</a>
    </div>

    <h2>Datos del Empleado</h2>
    <div class="detalle-empleado">
        <p><strong>Nombre y Apellidos:</strong> <?php echo $nombreCompleto; ?></p>
        <p><strong>Correo:</strong> <?php echo $correo; ?></p>
        <p><strong>Rol:</strong> <?php echo $rol; ?></p>
        <p><strong>Foto:</strong><br>
            <img src="archivos/<?php echo $row['archivo']; ?>" alt="Foto de <?php echo $row['nombre']; ?>" width="150">
        </p>
    </div>
    <div class="regresar">
        <a href="empleados_lista.php">Regresar al listado</a>
    </div>
</body>
</html>
