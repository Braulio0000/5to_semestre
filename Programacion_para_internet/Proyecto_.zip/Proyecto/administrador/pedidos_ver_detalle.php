<?php
session_start();
if (!isset($_SESSION['idUser'])) {  // Si no hay sesión activa
    header("Location: login.php");  // Redirige al login
    exit();
}
require "funciones/conecta_pedidos_productos.php";
$con = conecta();

// Captura el ID del pedido desde la URL
$idPedido = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($idPedido == 0) {
    echo "Pedido no válido.";
    exit();
}

// Consulta para obtener los productos del pedido
$sql = "SELECT pp.id, p.nombre AS producto, pp.cantidad, pp.costo 
        FROM pedidos_productos pp
        JOIN productos p ON pp.id_producto = p.id
        WHERE pp.id_pedido = $idPedido";
$res = $con->query($sql);

if ($res && $res->num_rows > 0) {
    $productos = [];
    while ($row = $res->fetch_assoc()) {
        $productos[] = $row;
    }
} else {
    echo "No se encontraron productos para este pedido.";
    exit();
}

// Calcular el gran total
$totalPedido = 0;
foreach ($productos as $producto) {
    $totalPedido += $producto['cantidad'] * $producto['costo'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle de Pedido</title>
    <link rel="stylesheet" href="estilos_ver_detalle.css">
</head>
<body>

    <div class="menu">
        <a href="bienvenido.php">INICIO</a>
        <a href="empleados_lista.php">EMPLEADOS</a>
        <a href="productos_lista.php">PRODUCTOS</a>
        <a href="promociones_lista.php">PROMOCIONES</a>
        <a href="pedidos.php">PEDIDOS</a>
        <a href="cerrarSesion.php">CERRAR SESIÓN</a>
    </div>

    <h2>Detalles del Pedido #<?php echo $idPedido; ?></h2>
    <div class="detalle-pedido">
        <table>
            <tr>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Costo</th>
                <th>Subtotal</th>
            </tr>
            <?php
            foreach ($productos as $producto) {
                $subtotal = $producto['cantidad'] * $producto['costo'];
                echo "<tr>";
                echo "<td>" . $producto['producto'] . "</td>";
                echo "<td>" . $producto['cantidad'] . "</td>";
                echo "<td>$" . number_format($producto['costo'], 2) . "</td>";
                echo "<td>$" . number_format($subtotal, 2) . "</td>";
                echo "</tr>";
            }
            ?>
            <tr>
                <td colspan="3"><strong>Total</strong></td>
                <td><strong>$<?php echo number_format($totalPedido, 2); ?></strong></td>
            </tr>
        </table>
    </div>

    <div class="regresar">
        <a href="pedidos.php">Regresar al listado</a>
    </div>

</body>
</html>
