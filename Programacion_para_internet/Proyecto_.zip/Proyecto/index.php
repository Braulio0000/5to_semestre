<?php
session_start(); // Inicia la sesión para acceder a las variables de sesión

// Verificar si el usuario está logueado
if (isset($_SESSION['nombreUser'])) {
    // Si está logueado, mostrar el nombre
    $nombreUsuario = $_SESSION['nombreUser'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Bienvenido</title>
    <link rel="stylesheet" href="home.css"> 
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet"> 
    <!-- Incluye Bootstrap y FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <!-- Título -->
    <h2 class="text-center mt-4">LEROPE</h2>    
    
    <!-- Menú de navegación -->
    <div class="menu d-flex justify-content-between align-items-center">
        <div>
            <a href="index.php">HOME</a>
            <a href="producto.php">PRODUCTOS</a>
            <a href="contacto.php">CONTACTO</a>
            <?php
            // Verificar si la sesión está activa
            if (isset($_SESSION['nombreUser'])) {
                echo '<a href="loginOut.php">CERRAR SESIÓN</a>';
                echo '<p class="welcome-message">Bienvenido, ' . $_SESSION['nombreUser'] . '</p>';
            } else {
                echo '<a href="loginCliente.php">LOG IN</a>';
            }
            ?>
        </div>
        <!-- Redes sociales y carrito -->
        <div class="d-flex align-items-center">
            <!-- Íconos de redes sociales -->
            <a href="https://www.facebook.com" target="_blank" class="ml-3" title="Facebook">
                <i class="fab fa-facebook-f" style="font-size: 24px; color: #4267B2;"></i>
            </a>
            <a href="https://www.twitter.com" target="_blank" class="ml-3" title="Twitter">
                <i class="fab fa-twitter" style="font-size: 24px; color: #1DA1F2;"></i>
            </a>
            <a href="https://www.instagram.com" target="_blank" class="ml-3" title="Instagram">
                <i class="fab fa-instagram" style="font-size: 24px; color: #E4405F;"></i>
            </a>
            <!-- Ícono del carrito -->
            <a href="carrito.php" class="cart-icon ml-3" title="Carrito">
                <i class="fas fa-shopping-cart" style="font-size: 24px;"></i>
            </a>
        </div>
    </div>
    
    <!-- Carrusel para las promociones -->
    <div id="promoCarousel" class="carousel slide mt-4" data-ride="carousel">
        <div class="carousel-inner">
            <?php
            // Conexión a la base de datos
            $conn = new mysqli("localhost", "root", "", "proyecto");
            if ($conn->connect_error) {
                die("Error de conexión: " . $conn->connect_error);
            }

            // Consulta para obtener promociones activas y no eliminadas al azar
            $sql = "SELECT archivo FROM promociones WHERE status = 1 AND eliminado = 0 ORDER BY RAND() LIMIT 5";
            $result = $conn->query($sql);

            $active = true;
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="carousel-item ' . ($active ? 'active' : '') . '">';
                    echo '<img src="administrador/archivos_promociones/' . $row['archivo'] . '" class="d-block w-100" alt="Promoción">';
                    echo '</div>';
                    $active = false;
                }
            }
            ?>
        </div>
        <a class="carousel-control-prev" href="#promoCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        </a>
        <a class="carousel-control-next" href="#promoCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
        </a>
    </div>

    <!-- Sección de productos al azar -->
    <div class="products mt-5">
        <h3 class="text-center">Productos destacados</h3>
        <div class="row">
            <?php
            // Consulta para obtener 6 productos activos y no eliminados al azar
            $sql = "SELECT nombre, archivo, costo, codigo FROM productos WHERE status = 1 AND eliminado = 0 ORDER BY RAND() LIMIT 6";
            $result = $conn->query($sql);

            if (!$result) {
              die("Error en la consulta SQL: " . $conn->error);
            }

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="col-md-4 text-center">';
                    echo '<img src="administrador/archivos_productos/' . $row['archivo'] . '" class="img-fluid" alt="' . $row['nombre'] . '">';
                    echo '<p>' . $row['nombre'] . '</p>';
                    echo '<p><strong>precio:</strong> $' . number_format($row['costo'], 2) . '</p>';
                    echo '<p><strong>codigo:</strong> ' . $row['codigo'] . '</p>';
                    echo '</div>';
                }
            }
            $conn->close();
            ?>
        </div>
    </div>

    <!-- Pie de página -->
    <h5 class="text-center mt-4">© Copyright 1999-2025 Todos los derechos reservados</h5>
</div>
</body>
</html>
