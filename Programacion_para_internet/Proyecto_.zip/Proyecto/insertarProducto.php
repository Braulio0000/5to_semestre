<?php
session_start();

// Incluir las funciones de conexión para las tablas 'pedidos' y 'pedidos_productos'
require 'funciones/conecta_pedidos.php';
require 'funciones/conecta_pedidos_productos.php';

// Obtener la conexión a la base de datos de pedidos
$conPedidos = conecta_pedidos();

// Obtener la conexión a la base de datos de pedidos_productos
$conPedidosProductos = conecta_pedidos_productos();

$idProducto = $_POST['id_producto'];
$cantidad = $_POST['cantidad'];
$idCliente = $_SESSION['idUser'];

// Verifica si hay un pedido abierto para el cliente
$sqlPedidoAbierto = "SELECT id FROM pedidos WHERE id_cliente = $idCliente AND status = 0";
$resPedido = $conPedidos->query($sqlPedidoAbierto);

if ($resPedido->num_rows > 0) {
    $pedido = $resPedido->fetch_assoc();
    $idPedido = $pedido['id'];
} else {
    // Si no hay pedido abierto, crea uno
    $sqlInsertPedido = "INSERT INTO pedidos (fecha, id_cliente, status) VALUES (NOW(), $idCliente, 0)";
    $conPedidos->query($sqlInsertPedido);
    $idPedido = $conPedidos->insert_id;
}

// Obtén el costo del producto
$sqlProducto = "SELECT costo FROM productos WHERE id = $idProducto";
$resProducto = $conPedidosProductos->query($sqlProducto);

if ($resProducto->num_rows > 0) {
    $producto = $resProducto->fetch_assoc();
    $costo = $producto['costo'];

    // Verifica si ya existe el producto en el pedido
    $sqlVerificaProducto = "SELECT id, cantidad FROM pedidos_productos WHERE id_pedido = $idPedido AND id_producto = $idProducto";
    $resVerifica = $conPedidosProductos->query($sqlVerificaProducto);

    if ($resVerifica->num_rows > 0) {
        // Si ya existe, actualiza la cantidad
        $productoPedido = $resVerifica->fetch_assoc();
        $nuevaCantidad = $productoPedido['cantidad'] + $cantidad;

        $sqlUpdate = "UPDATE pedidos_productos SET cantidad = $nuevaCantidad WHERE id = " . $productoPedido['id'];
        $conPedidosProductos->query($sqlUpdate);
    } else {
        // Si no existe, inserta el producto
        $sqlInsertProducto = "INSERT INTO pedidos_productos (id_pedido, id_producto, cantidad, costo) 
                              VALUES ($idPedido, $idProducto, $cantidad, $costo)";
        $conPedidosProductos->query($sqlInsertProducto);
    }

    echo 1; // Producto agregado con éxito
} else {
    echo 0; // Error: producto no encontrado
}

?>
