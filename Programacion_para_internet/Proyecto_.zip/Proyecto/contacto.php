<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto</title>
    <link rel="stylesheet" href="contacto.css">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <!-- Incluye Bootstrap y FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <!-- Menú de navegación -->
    <div class="menu d-flex justify-content-between align-items-center bg-light p-3 shadow-sm">
        <div>
            <a href="index.php">HOME</a>
            <a href="producto.php">PRODUCTOS</a>
            <a href="contacto.php">CONTACTO</a>
        </div>
        <div class="d-flex align-items-center">
            <a href="carrito.php" class="mr-3"><i class="fas fa-shopping-cart"></i></a>
            <a href="https://facebook.com" class="mr-2"><i class="fab fa-facebook-f"></i></a>
            <a href="https://twitter.com" class="mr-2"><i class="fab fa-twitter"></i></a>
            <a href="https://instagram.com"><i class="fab fa-instagram"></i></a>
        </div>
    </div>

    <!-- Contenido del formulario de contacto -->
    <div class="container mt-5">
        <div class="d-flex justify-content-end mb-4"> 
            <a href="index.php" class="btn btn-secondary">REGRESAR</a> 
        </div>
        <h2 class="text-center mb-4">Contáctanos</h2>
        <form id="formulario-contacto" class="needs-validation" novalidate>
            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="nombre">Nombre</label>
                    <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Tu nombre" required>
                    <div class="invalid-feedback">Por favor, ingresa tu nombre.</div>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="email">Correo Electrónico</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Tu correo electrónico" required>
                    <div class="invalid-feedback">Por favor, ingresa un correo electrónico válido.</div>
                </div>
            </div>
            <div class="form-group">
                <label for="mensaje">Mensaje</label>
                <textarea class="form-control" id="mensaje" name="mensaje" rows="5" placeholder="Tu mensaje" required></textarea>
                <div class="invalid-feedback">Por favor, ingresa tu mensaje.</div>
            </div>
            <button class="btn btn-primary btn-block" type="submit">Enviar</button>
        </form>

        <div id="mensaje-exito" class="alert alert-success d-none"></div>
        <div id="mensaje-error" class="alert alert-danger d-none"></div>
    </div>

    <script>
        // Validación de formulario de Bootstrap
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
    </script>

    <!-- Contenedor para el mensaje -->
<div id="mensaje-exito"></div>
<div id="mensaje-error"></div>

        <script>
            document.getElementById('formulario-contacto').addEventListener('submit', function(e) {
                e.preventDefault(); // Prevenir el envío estándar del formulario

                const form = e.target;
                const formData = new FormData(form);

                // Realizar la solicitud AJAX con fetch
                fetch('recibe.php', {
                    method: 'POST',
                    body: formData,
                })
                .then(response => response.json())
                .then(data => {
                    // Limpiar mensajes previos
                    document.getElementById('mensaje-exito').classList.add('d-none');
                    document.getElementById('mensaje-error').classList.add('d-none');

                    // Mostrar el mensaje adecuado
                    if (data.success) {
                        const exito = document.getElementById('mensaje-exito');
                        exito.textContent = data.message;
                        exito.classList.remove('d-none');
                    } else {
                        const error = document.getElementById('mensaje-error');
                        error.textContent = data.message;
                        error.classList.remove('d-none');
                    }
                })
                .catch(error => {
                    const errorDiv = document.getElementById('mensaje-error');
                    errorDiv.textContent = 'Ocurrió un error al procesar el formulario.';
                    errorDiv.classList.remove('d-none');
                });
            });
        </script>


</body>
</html>
