<?php
//conexion a la base de datos "pedidos_productos".php
define("HOST",'localhost');
define("BD",'proyecto');
define("USER_BD",'root');
define("PASS_BD",'');

function conecta_pedidos_productos() {
  $con = new mysqli(HOST, USER_BD, PASS_BD, BD);
  return $con;
}
?>

