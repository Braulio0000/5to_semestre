<?php
//conexion a la base de datos "pedidos"
define("HOST",'localhost');
define("BD",'proyecto');
define("USER_BD",'root');
define("PASS_BD",'');

function conecta_pedidos() {
  $con = new mysqli(HOST, USER_BD, PASS_BD, BD);
  return $con;
}
?>

