<?php
session_start(); // Iniciar sesión

// Verificar si el usuario está logueado
if (!isset($_SESSION['idUser'])) {
    header("Location: loginCliente.php");  // Redirigir al login si no está logueado
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras</title>
    <link rel="stylesheet" href="carritoEstilos.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <style>
        .error-message {
            color: red;
            display: none;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Carrito de Compras</h1>
    <div class="d-flex justify-content-end mb-4"> 
        <a href="index.php" class="boton">REGRESAR</a> 
    </div> 

    <?php
    // Verificar si el carrito no está vacío
    if (isset($_SESSION['carrito']) && !empty($_SESSION['carrito'])) {
        echo '<table>';
        echo '<tr><th>Producto</th><th>Cantidad</th><th>Precio</th><th>Total</th><th>Acciones</th></tr>';
        
        // Mostrar productos en el carrito
        $total = 0;
        foreach ($_SESSION['carrito'] as $idProducto => $producto) {
            // Asegurarse de que $producto es un array
            if (is_array($producto)) {
                $cantidad = $producto['cantidad'];

                require_once 'funciones/conecta_productos.php'; // Usar require_once
                $con = conecta();
                $query = "SELECT * FROM productos WHERE id = $idProducto";
                $resultado = $con->query($query);
                $producto_db = $resultado->fetch_assoc();

                if ($producto_db) {
                    $totalProducto = $producto_db['costo'] * $cantidad;
                    $total += $totalProducto;

                    echo "<tr>
                            <td>" . $producto_db['nombre'] . "</td>
                            <td>
                                <input type='number' value='" . $cantidad . "' min='1' data-id='" . $idProducto . "' class='cantidad'>
                            </td>
                            <td>$" . $producto_db['costo'] . "</td>
                            <td>$" . $totalProducto . "</td>
                            <td><button class='eliminar' data-id='" . $idProducto . "'>Eliminar</button></td>
                          </tr>";
                }
            }
        }

        echo '<tr><td colspan="4">Total</td><td>$' . $total . '</td></tr>';
        echo '</table>';
        echo '<button id="confirmarCompra">Confirmar Compra</button>';
    } else {
        echo '<p>No tienes productos en tu carrito.</p>';
    }
    ?>

    <p class="error-message">La cantidad debe ser mayor que cero.</p>
    <button onclick="window.location.href='index.php'">Seguir comprando</button>
</div>

<script>
$(document).ready(function() {
    // Verificación inicial para el botón de confirmar compra
    let allValid = true;
    $('.cantidad').each(function() {
        if ($(this).val() <= 0) {
            allValid = false;
        }
    });
    if (allValid) {
        $('#confirmarCompra').prop('disabled', false);
    }

    // Actualizar cantidad del producto
    $('.cantidad').on('change', function() {
        var idProducto = $(this).data('id');
        var cantidad = $(this).val();
        
        if (cantidad > 0) {
            $.ajax({
                url: 'actualizar_carrito.php',
                type: 'POST',
                data: { id: idProducto, cantidad: cantidad },
                success: function(response) {
                    location.reload(); // Recargar la página para reflejar los cambios
                }
            });
            $('.error-message').hide();
        } else {
            $('.error-message').show();
            $('#confirmarCompra').prop('disabled', true);
        }
    });

    // Eliminar producto del carrito
    $('.eliminar').on('click', function() {
        var idProducto = $(this).data('id');
        $.ajax({
            url: 'eliminar_carrito.php',
            type: 'POST',
            data: { id: idProducto },
            success: function(response) {
                location.reload(); // Recargar la página para reflejar los cambios
            }
        });
    });

    // Confirmar compra
    $('#confirmarCompra').on('click', function() {
        $.ajax({
            url: 'confirmar_compra.php',
            type: 'POST',
            success: function(response) {
                $('body').html(response); // Mostrar el mensaje de agradecimiento y total
            }
        });
    });
});
</script>
</body>
</html>
