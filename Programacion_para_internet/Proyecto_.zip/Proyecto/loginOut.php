<?php
session_start();

// Verificar si la sesión está activa antes de destruirla
if (isset($_SESSION['idUser'])) {
    session_unset(); // Libera todas las variables de sesión
    session_destroy(); // Destruye la sesión
    session_regenerate_id(true); // Regenera el ID de sesión para prevenir hijacking
}

// Redirige al usuario a la página de login
header("Location: index.php");
exit();
?>
