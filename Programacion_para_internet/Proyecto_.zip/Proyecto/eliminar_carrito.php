<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['idUser'])) {
    die("Debe estar logueado para modificar el carrito.");
}

// Obtener el ID del producto
$idProducto = isset($_POST['id']) ? (int)$_POST['id'] : 0;

// Validar y eliminar del carrito
if (isset($_SESSION['carrito'][$idProducto])) {
    unset($_SESSION['carrito'][$idProducto]);
    echo json_encode(['status' => 'success', 'message' => 'Producto eliminado del carrito.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Producto no encontrado en el carrito.']);
}
?>
