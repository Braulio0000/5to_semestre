function agregarAlCarrito(idProducto) {
    const cantidad = document.getElementById('cantidad-' + idProducto).value;
    if (cantidad <= 0 || !cantidad) {
        alert('Por favor, ingresa una cantidad válida.');
        return;
    }

    // AJAX para agregar al carrito
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'agregarAlCarrito.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            const respuesta = xhr.responseText;
            document.getElementById('mensaje').innerHTML = respuesta;
        }
    };
    xhr.send('id_producto=' + idProducto + '&cantidad=' + cantidad);
}
