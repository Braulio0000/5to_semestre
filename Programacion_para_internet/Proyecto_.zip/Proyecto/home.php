<head>
    <meta charset="UTF-8">
    <title>Bienvenido</title>
    <link rel="stylesheet" href="home.css">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <!-- Incluye Bootstrap y FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <!-- Título -->
        <h2 class="text-center mt-4">LEROPE</h2>    
        
        <!-- Menú de navegación -->
        <div class="menu d-flex justify-content-between align-items-center">
            <?php
                // Solo iniciamos sesión si no ha sido iniciada previamente
                if (session_status() == PHP_SESSION_NONE) {
                    session_start();
                }
            ?>
            <div>
                <a href="index.php">HOME</a>
                <a href="producto.php">PRODUCTOS</a>
                <a href="contacto.php">CONTACTO</a>

                <?php
                // Verificar si la sesión está activa
                if (isset($_SESSION['nombreUser'])) {
                    echo '<a href="loginOut.php">CERRAR SESIÓN</a>';
                    echo '<p>Bienvenido, ' . $_SESSION['nombreUser'] . '</p>';
                } else {
                    echo '<a href="loginCliente.php">LOG IN</a>';
                }
                ?>
            </div>
        </div>
    </div>
</body>
