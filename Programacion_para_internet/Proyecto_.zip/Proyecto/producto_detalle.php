<?php
session_start(); // Iniciar sesión

// Verificar si el usuario está logueado
$usuario_logueado = isset($_SESSION['idUser']);

// Incluir archivo de conexión a la base de datos
include 'funciones/conecta_productos.php';

// Establecer la conexión
$con = conecta();

// Obtener el ID del producto desde la URL
$idProducto = isset($_GET['id']) ? $_GET['id'] : 0;

// Consultar la base de datos para obtener los detalles del producto
$query = "SELECT * FROM productos WHERE id = $idProducto AND eliminado = 0";
$resultado = $con->query($query);

// Verificar si el producto existe
if ($resultado->num_rows > 0) {
    $producto = $resultado->fetch_assoc();
} else {
    echo '<p>Producto no encontrado.</p>';
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle del Producto</title>
    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="producto.css">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <!-- Incluye Bootstrap y FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <!-- Menú de navegación -->
    <div class="menu d-flex justify-content-between align-items-center">
        <div>
            <a href="index.php">HOME</a>
            <a href="producto.php">PRODUCTOS</a>
            <a href="contacto.php">CONTACTO</a>
            <?php
            // Verificar si la sesión está activa
            if (isset($_SESSION['nombreUser'])) {
                echo '<a href="loginOut.php">CERRAR SESIÓN</a>';
                echo '<p class="welcome-message">Bienvenido, ' . $_SESSION['nombreUser'] . '</p>';
            } else {
                echo '<a href="loginCliente.php">LOG IN</a>';
            }
            ?>
        </div>
        <!-- Redes sociales y carrito -->
        <div class="d-flex align-items-center">
            <!-- Íconos de redes sociales -->
            <a href="https://www.facebook.com" target="_blank" class="ml-3" title="Facebook">
                <i class="fab fa-facebook-f" style="font-size: 24px; color: #4267B2;"></i>
            </a>
            <a href="https://www.twitter.com" target="_blank" class="ml-3" title="Twitter">
                <i class="fab fa-twitter" style="font-size: 24px; color: #1DA1F2;"></i>
            </a>
            <a href="https://www.instagram.com" target="_blank" class="ml-3" title="Instagram">
                <i class="fab fa-instagram" style="font-size: 24px; color: #E4405F;"></i>
            </a>
            <!-- Ícono del carrito -->
            <a href="carrito.php" class="cart-icon ml-3" title="Carrito">
                <i class="fas fa-shopping-cart" style="font-size: 24px;"></i>
            </a>
        </div>
    </div>

    <!-- Detalles del producto -->
    <div class="d-flex justify-content-end mb-4"> 
        <a href="index.php" class="btn btn-secondary">REGRESAR</a> 
    </div>
    <div class="product-detail mt-5">
        <h1 class="text-center"><?php echo $producto['nombre']; ?></h1>
        <div class="text-center">
            <img src="administrador/archivos_productos/<?php echo $producto['archivo']; ?>" alt="<?php echo $producto['nombre']; ?>" class="img-fluid">
        </div>
        <p class="text-center price mt-3">Precio: $<?php echo $producto['costo']; ?></p>
        <p class="text-center">Código: <?php echo $producto['codigo']; ?></p>

        <!-- Mostrar link si el usuario está logueado -->
        <?php if ($usuario_logueado) { ?>
            <div class="d-flex justify-content-center mt-4">
                <input type="number" id="cantidad-<?php echo $producto['id']; ?>" placeholder="Cantidad" min="1" class="form-control mr-2" style="width: 100px;">
                <a href="#" class="btn btn-primary" id="agregar-carrito-link">Agregar al carrito</a>
            </div>
        <?php } else { ?>
            <p class="text-center text-danger mt-4">Debes estar logueado para agregar al carrito.</p>
        <?php } ?>

        <div class="text-center mt-4">
            <button class="btn btn-secondary" onclick="window.location.href='producto.php'">Volver a los productos</button>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#agregar-carrito-link').on('click', function(e) {
        e.preventDefault();
        var idProducto = <?php echo $producto['id']; ?>;
        var cantidad = $('#cantidad-' + idProducto).val();
        window.location.href = 'agregar_carrito.php?producto_id=' + idProducto + '&cantidad=' + cantidad;
    });
});
</script>
</body>
</html>

<?php
// Cerrar la conexión
if ($con) {
    $con->close();
}
?>
